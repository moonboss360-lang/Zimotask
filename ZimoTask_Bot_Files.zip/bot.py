import os
import threading
import logging

from flask import Flask
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from telegram.error import TelegramError

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN")
WEBSITE_URL = os.getenv("WEBSITE_URL", "").strip()

if not BOT_TOKEN:
    raise RuntimeError(
        "BOT_TOKEN is missing. Add BOT_TOKEN in Render Environment Variables."
    )

CHANNELS = [
    {
        "name": "Zimo Task",
        "username": "@zimotask",
        "url": "https://t.me/zimotask",
    },
    {
        "name": "Zimo Task Payment",
        "username": "@zimotaskpayment",
        "url": "https://t.me/zimotaskpayment",
    },
    {
        "name": "Zimo Task Support",
        "username": "@zimotasksupport",
        "url": "https://t.me/zimotasksupport",
    },
]


def join_keyboard():
    buttons = []
    for channel in CHANNELS:
        buttons.append([
            InlineKeyboardButton(
                f"📢 JOIN {channel['name']}",
                url=channel["url"],
            )
        ])

    buttons.append([
        InlineKeyboardButton("✅ VERIFY", callback_data="verify")
    ])

    return InlineKeyboardMarkup(buttons)


def website_keyboard():
    if not WEBSITE_URL:
        return None

    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "🌐 OPEN ZIMO TASK WEBSITE",
                url=WEBSITE_URL,
            )
        ]
    ])


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "👋 <b>Welcome to Zimo Task!</b>\n\n"
        "🎯 আমাদের প্ল্যাটফর্ম ব্যবহার করার আগে নিচের "
        "সবগুলো Telegram Channel-এ Join করতে হবে।\n\n"
        "👇 প্রথমে সবগুলো Channel-এ Join করুন।\n"
        "তারপর নিচের <b>✅ VERIFY</b> বাটনে ক্লিক করুন।\n\n"
        "⚠️ সবগুলো Channel-এ Join না করলে Verification সফল হবে না।"
    )

    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=join_keyboard(),
        disable_web_page_preview=True,
    )


async def get_missing_channels(user_id: int, context: ContextTypes.DEFAULT_TYPE):
    missing = []

    for channel in CHANNELS:
        try:
            member = await context.bot.get_chat_member(
                chat_id=channel["username"],
                user_id=user_id,
            )

            if member.status in ("member", "administrator", "creator"):
                continue

            if (
                member.status == "restricted"
                and getattr(member, "is_member", False)
            ):
                continue

            missing.append(channel)

        except TelegramError as error:
            logger.error(
                "Membership check failed for %s: %s",
                channel["username"],
                error,
            )
            missing.append(channel)

    return missing


async def verify_callback(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    query = update.callback_query
    await query.answer("🔍 Checking your membership...")

    missing = await get_missing_channels(
        query.from_user.id,
        context,
    )

    if missing:
        buttons = []

        for channel in missing:
            buttons.append([
                InlineKeyboardButton(
                    f"📢 JOIN {channel['name']}",
                    url=channel["url"],
                )
            ])

        buttons.append([
            InlineKeyboardButton(
                "🔄 VERIFY AGAIN",
                callback_data="verify",
            )
        ])

        text = (
            "❌ <b>Verification Failed!</b>\n\n"
            "আপনি এখনো নিচের Channel-গুলোতে Join করেননি:\n\n"
        )

        for channel in missing:
            text += f"• {channel['name']}\n"

        text += (
            "\n👇 আগে বাকি Channel-গুলোতে Join করুন।"
            "\nতারপর আবার <b>🔄 VERIFY AGAIN</b> চাপুন।"
        )

        await query.edit_message_text(
            text,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(buttons),
            disable_web_page_preview=True,
        )
        return

    text = (
        "🎉 <b>Verification Successful!</b>\n\n"
        "✅ আপনি সবগুলো Required Channel-এ Join করেছেন।\n\n"
        "🚀 <b>আপনার Zimo Task account এখন ready!</b>\n\n"
    )

    keyboard = website_keyboard()

    if keyboard:
        text += "নিচের বাটনে ক্লিক করে আমাদের Website-এ যান। 👇"
    else:
        text += "🌐 Website link খুব শীঘ্রই এখানে যুক্ত করা হবে।"

    await query.edit_message_text(
        text,
        parse_mode="HTML",
        reply_markup=keyboard,
        disable_web_page_preview=True,
    )


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error(
        "Exception while handling update:",
        exc_info=context.error,
    )


# Render Web Service health server
flask_app = Flask(__name__)


@flask_app.route("/")
def home():
    return "Zimo Task Bot is running successfully! 🚀", 200


@flask_app.route("/health")
def health():
    return "OK", 200


def run_web_server():
    port = int(os.environ.get("PORT", "10000"))
    flask_app.run(
        host="0.0.0.0",
        port=port,
        debug=False,
        use_reloader=False,
    )


def main():
    threading.Thread(
        target=run_web_server,
        daemon=True,
    ).start()

    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .build()
    )

    application.add_handler(CommandHandler("start", start))

    application.add_handler(
        CallbackQueryHandler(
            verify_callback,
            pattern="^verify$",
        )
    )

    application.add_error_handler(error_handler)

    logger.info("Zimo Task Bot is starting...")

    application.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
